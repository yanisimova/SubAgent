from pathlib import Path
import json, subprocess, sys
a=Path(__file__).resolve().parent
r=a.parents[1]
def validate(v,s):
 types={'object':dict,'array':list,'string':str}
 if s.get('type') in types: assert isinstance(v,types[s['type']]), 'Wrong type'
 if isinstance(v,dict):
  assert all(k in v for k in s.get('required',[])), 'Missing key'
  if s.get('additionalProperties') is False: assert set(v)<=set(s.get('properties',{})), 'Extra key'
  for k,x in v.items():
   if k in s.get('properties',{}):validate(x,s['properties'][k])
 if isinstance(v,list) and 'items' in s:
  for x in v:validate(x,s['items'])
subprocess.run([sys.executable,str(r/'tools/check_frozen_core.py')],check=True)
outs={}
for c in sorted((a/'cases').glob('*.json')):
 validate(json.loads(c.read_text()),json.loads((r/'core/input_schema.json').read_text()))
 p=a/'responses'/(c.stem+'_response.json'); d=json.loads(p.read_text());outs[c.stem]=d
 validate(d,json.loads((r/'core/output_schema.json').read_text()))
 subprocess.run([sys.executable,str(r/'tools/validate_response.py'),str(p)],check=True)
for k in ['contrast_1','contrast_2','hype']:
 assert outs[k]['general_et_finding']==outs['primary']['general_et_finding']
 assert outs[k]['evidence']==outs['primary']['evidence']
assert 'abstain' in outs['insufficient']['general_et_finding'].lower()
assert outs['contrast_1']['recommendation_management_implication']!=outs['primary']['recommendation_management_implication']
print('PASS: 5 cases and 5 saved responses satisfy all constraints used in the supplied schemas; frozen core, fixed-evidence invariance, context action and abstention checks passed. These checks do not establish factual accuracy or independent runtime reliability.')
