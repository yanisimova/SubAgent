# Classification criteria

Use the course-derived gated instrument as an analytical framework, not a settled scientific taxonomy. The Assignment 4 memo and common instructions were read directly. Detailed Chapter 11 criteria below follow the prior team package and its attributed candidate paraphrases; original chapter and lecture alignment still require student verification.

1. Scope: name the deployed usable system, comparator, evidence cutoff and long-range horizon. Do not classify an isolated algorithm or hypothetical AGI as an already usable system.
2. Barrier: identify the prior constraint on an activity. Distinguish making an existing activity easier from dissolving a defining constraint.
3. Suppression: ask what would happen if the system disappeared. Evidence of dependent infrastructure supports durable dissolution; hypothetical collapse does not. Local manual fallback alone cannot settle technology-wide significance.
4. Tiers: assess whether dissolution reaches at least two societal tiers. Two industries or research domains alone do not establish two tiers.
5. Assess six criteria: order-of-magnitude change, widespread impact, paradigm shift, catalytic effects, democratization, irreversibility. For each name the evidence, comparator or limitation. Use Supported, Provisional, Not established or Contradicted. No invented summed cutoff.
6. Declare prospective or retrospective mode. Emerging cases can reach a qualified Potential Promethean hypothesis; they cannot establish Confirmed historical irreversibility by prediction.

Incremental: improvement within existing assumptions and workflows. Breakthrough: meaningful new feasible capability or major constraint reduction, without demonstrated multi-tier durable dissolution. Potential Promethean: a qualified, evidence-linked hypothesis of multi-tier barrier dissolution with missing gates and long-term uncertainty stated. If the dossier cannot distinguish breakthrough from potential, report the lower empirical finding plus the unresolved higher hypothesis, or abstain from a firm category. Do not force the highest label.

Hype, funding, popularity and novelty do not establish significance. Task gains do not imply tenfold improvement. One support deployment does not establish consulting gains or hospital efficacy. Source stage, population, baseline and date limit transfer.
