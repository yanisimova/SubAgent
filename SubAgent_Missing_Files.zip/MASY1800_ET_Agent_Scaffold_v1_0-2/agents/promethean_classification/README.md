# Promethean Classification Agent

Yulia Anisimova — Emerging Technologies Section 103 — Assignment 4. Version 1.0-student-review.

Primary use: evaluate LLM-based summary drafting for a hypothetical small analytical consulting firm. Read records/agent_record.md, classification_criteria.md and records/test_record.md. No API key is needed. Frozen schemas and tools are unchanged.

From the scaffold directory:
```bash
python tools/check_frozen_core.py
python tools/build_prompt.py --agent agents/promethean_classification --case agents/promethean_classification/cases/primary.json
```
Paste work/promethean_classification_primary_prompt.txt into ChatGPT. Save the returned JSON under a new filename and run `python tools/validate_response.py path/to/response.json`. Repeat contrast_1, contrast_2, hype and insufficient cases. Run `python agents/promethean_classification/verify_package.py` to check saved files.

The package includes representative AI-authored responses and an explicitly constructed overclaim. Personal endorsement, original chapter verification and independent fresh-session replay are not claimed. The team Word report’s human verification does not automatically certify this later individual candidate.
