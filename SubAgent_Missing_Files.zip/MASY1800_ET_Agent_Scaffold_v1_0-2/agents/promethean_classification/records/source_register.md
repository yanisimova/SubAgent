# Source register

S1: Brynjolfsson, Li and Raymond. Generative AI at Work. https://arxiv.org/abs/2304.11771v2 . Revision 2024-11-06; original abstract checked 2026-10-20. Supports heterogeneous assistance gains in customer support. Full methods not reviewed; no direct consulting or clinical evidence and no claim about 2026 frontier capability.

S2: NIST AI 600-1. https://doi.org/10.6028/NIST.AI.600-1 . Published 2024-07-26; official publication abstract checked 2026-10-20. Voluntary cross-sector governance context, not legal clearance or efficacy evidence.

S3: Repository Assignment 4 memo, Common Individual Instructions and Agent Record Template, at initial main commit 99bd675b1b2e3ac26c81d98339bf71069b940222. Read in full for this task.

Framework lineage: prior team synthesis and the explicit Chapter 11 paraphrase in Harry-max264/Lab4 commit 58a74ccd8b02d108fccfcdac5ce59f82dee2efe7, attributed there to Fortino August 2026 revision 0.1. The original chapter was not independently retrieved for this individual completion. No full restricted reading is republished. The detailed gates need student verification against the assigned chapter.

This candidate was completed after the team synthesis and reuses its methodological work with attribution. It must not be represented as an independent candidate that existed before the team workshop. No other student’s personal judgment or test ownership is claimed.
