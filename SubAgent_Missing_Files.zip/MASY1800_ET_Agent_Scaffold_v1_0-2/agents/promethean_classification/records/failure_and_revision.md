# Preserved weakness and revision

Observed repository gap: initial main commit 99bd675b1b2e3ac26c81d98339bf71069b940222 had only blank specialist templates and a toy example. There was no completed specialist output to audit.

The adjacent diagnostic_overclaim.txt is explicitly a constructed negative example, not a fabricated historical run. It wrongly transfers support-study results to consulting, promises local value, and turns broad significance into rollout advocacy.

Control added: instructions require domain-transfer qualification, a local baseline, separate significance/application/organization findings, and a bounded recommendation. The final primary response withholds consulting benefit claims and requires comparison against existing work and templates. Contrast_2 withholds clinical endorsement. Hype preserves classification and conditions.

This is a diagnostic example and content review, not causal proof of improvement or an independent fresh-session retest. A future actual failed run must be retained unchanged with its prompt, model, date and revision history.
