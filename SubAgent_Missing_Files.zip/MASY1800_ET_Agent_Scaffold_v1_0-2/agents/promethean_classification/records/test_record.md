# Test record

Date: 2026-10-20. Five representative responses were authored by ChatGPT/Codex in the same development conversation. They are worked examples, not separate API executions or independent fresh-session trials. Exact reproducible prompt packets are in work/.

| Case | Broad finding | Local implication |
|---|---|---|
| Primary consulting | Provisional Breakthrough; higher hypothesis unresolved | Conditional six-week reviewed pilot |
| Contrast 1 posture only | Same finding and evidence | Offline evaluation before live projects |
| Contrast 2 hospital | Same finding and evidence | Defer autonomous clinical advice |
| Hype | Same finding and evidence | Reject pressure and retain bounded evaluation |
| Insufficient evidence | Abstention | Request definition and evidence |

Stable conclusion: broad significance across the four fixed-dossier cases. Appropriate change: exposure and action with posture, application and consequences. This demonstrates the intended behavior in saved examples; it does not establish stochastic reliability. See verification_log.txt for actual local checks.

For an independent replay, run each prompt in a fresh ChatGPT conversation, save the raw reply under a new filename and validate it. Record date/model/session and manually inspect sources and reasoning. Do not replace these examples or claim their authorship was independent.
